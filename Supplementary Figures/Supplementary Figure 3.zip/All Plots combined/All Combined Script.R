library(ggplot2)
library(ggpubr)
library(dplyr)
library(readxl)
library(RColorBrewer)
library(readr)


#protein class

#I took the top 5 from each of the group and combined them together. Some/many are overlapping as expected. 
# transcription factors converted to "TF" to remain consistent with the text, there is a list of some longer terms. 
#csv files were imported into the environment with the readr function. Pathways, clusters columns with text in them were brought in as character format. Anything else, with stats, ranking, etc, using numeric format. The 3 different analysis were loaded individually. 

#the remaining touch ups were finalised in photoshop. Fold enrichment and Sig score (i.e. pvalues) scale is essentially the same for all groups. With the early group of genes, obtaining FDR values were an issue due to the fewer number of genes. 
#best to export them out all at the same time and adjusing the size of the plots in photoshopso they all look the same. 
#in photoshop i added in the correct significance scales and arranged the fold enrichment for all. 

# Both and protein class and signaling pathways were arranged together using the function ggarrange


#############################################################################################

#signaling pathways 

#I took the top 5 from each of the group from the venn diagram, i.e. specific to OL, neurons and intersect and combined them together. Some/many are overlapping. 
#Pathway terms were shorted to fit and made consistend as possible with previous figures. The word "pathway was omitted alltoger from all terms. 
#csv files were imported into the environment with the readr function. Pathways, clusters columns with text in them were brought in as character format. Anything else, with stats, ranking, etc, using numeric format. The 3 different analysis were loaded individually. 

#the remaining touch ups were finalised in photoshop. Fold enrichment and Sig score (i.e. pvalues) scale is essentially the same for all groups. With the early group of genes, obtaining FDR values were an issue due to the fewer number of genes. 
#best to export them out all at the same time and adjusing the size of the plots in photoshopso they all look the same. 
#in photoshop i added in the correct significance scales and arranged the fold enrichment for all. 

#All of the 10 different datas, 5 for protein class (prcl) and 5 for pathways (path) were put into a folder and all ran together using the script below. 

######################################################################################################################

## qNSCI protein class
qNSCIprcl <- read_csv("qNSCIprcl.csv", 
                      col_types = cols(Cluster = col_number(), 
                                       FDR = col_skip(), Fold_Enrichment = col_skip(), 
                                       notes = col_skip(), notes_1 = col_skip(), 
                                       pvalue = col_skip()))

gg2prcl <- ggplot(qNSCIprcl) + geom_rect(data = qNSCIprcl,aes(fill = Cluster_2),xmin = -Inf,xmax = Inf, ymin = -Inf,ymax = Inf,alpha = 0.3) + 
  scale_fill_manual(values = alpha(c("#ff3030", "grey95", "#365ef8"), .3)) + 
  geom_point(aes(x = Cluster_2, y =reorder(Protein_Class, Fold_Score), size = Fold_Score, color=sig_score)) +
  labs(title="", y="") + scale_color_gradient2(low="blue", mid="grey60", high="black") + facet_grid(~ Cluster_2, scales = "free_x") + theme(strip.background = element_blank(), strip.text.x = element_blank())

gg2prcl<- gg2prcl + theme(legend.position = "left", plot.title=element_text(size=10, 
                                                                            face="bold", 
                                                                            family="Arial",
                                                                            color="black",
                                                                            hjust=0.5,
                                                                            lineheight=1.2),  # title
                          plot.subtitle=element_text(size=15, 
                                                     family="Arial",
                                                     face="bold",
                                                     hjust=0.5),  # subtitle
                          plot.caption=element_text(size=8),  # caption
                          
                          axis.title.x=element_text(vjust=10,  
                                                    size=0),  # X axis title
                          axis.title.y=element_text(size=15),  # Y axis title
                          axis.text.x=element_text(size=0, 
                                                   angle = 90,
                                                   vjust=.5,
                                                   face="bold"),  # X axis text
                          axis.text.y=element_text(size=14, face="bold", colour="black"),
                          
                          panel.grid.major = element_line(colour = "grey", size=.5),
                          panel.grid.minor = element_line(colour = "grey", 
                                                          size=.25, 
                                                          linetype = "dashed"),
                          panel.border = element_rect(size = 1.25, fill = NA),
                          axis.line.x = element_line(colour = "black", 
                                                     size=1.25, 
                                                     lineend = "butt"),
                          axis.line.y = element_line(colour = "black", 
                                                     size=1.25),
                          axis.ticks = element_line(size = 1, colour = "black"),
                          axis.ticks.length = unit(0, "cm")) 


## qNSCI Pathways
qNSCIpath2 <- read_csv("qNSCIpath2.csv", 
                       col_types = cols(Cluster = col_number(), 
                                        FDR = col_skip(), Fold_Enrichment = col_skip(), 
                                        notes = col_skip(), notes_1 = col_skip(), 
                                        pvalue = col_skip()))


gg2path <- ggplot(qNSCIpath2) + geom_rect(data = qNSCIpath2,aes(fill = Cluster_2),xmin = -Inf,xmax = Inf, ymin = -Inf,ymax = Inf,alpha = 0.3) + 
  scale_fill_manual(values = alpha(c("#ff3030", "grey95", "#365ef8"), .3)) + 
  geom_point(aes(x = Cluster_2, y =reorder(Pathways, Fold_Score), size = Fold_Score, color=sig_score)) +
  labs(title="", y="") + scale_color_gradient2(low="blue", mid="grey60", high="black") + facet_grid(~ Cluster_2, scales = "free_x") + theme(strip.background = element_blank(), strip.text.x = element_blank())

gg2path <- gg2path + theme(legend.position = "left", plot.title=element_text(size=10, 
                                                                             face="bold", 
                                                                             family="Arial",
                                                                             color="black",
                                                                             hjust=0.5,
                                                                             lineheight=1.2),  # title
                           plot.subtitle=element_text(size=15, 
                                                      family="Arial",
                                                      face="bold",
                                                      hjust=0.5),  # subtitle
                           plot.caption=element_text(size=8),  # caption
                           
                           axis.title.x=element_text(vjust=10,  
                                                     size=0),  # X axis title
                           axis.title.y=element_text(size=15),  # Y axis title
                           axis.text.x=element_text(size=0, 
                                                    angle = 90,
                                                    vjust=.5,
                                                    face="bold"),  # X axis text
                           axis.text.y=element_text(size=14, face="bold", colour="black"),
                           
                           panel.grid.major = element_line(colour = "grey", size=.5),
                           panel.grid.minor = element_line(colour = "grey", 
                                                           size=.25, 
                                                           linetype = "dashed"),
                           panel.border = element_rect(size = 1.25, fill = NA),
                           axis.line.x = element_line(colour = "black", 
                                                      size=1.25, 
                                                      lineend = "butt"),
                           axis.line.y = element_line(colour = "black", 
                                                      size=1.25),
                           axis.ticks = element_line(size = 1, colour = "black"),
                           axis.ticks.length = unit(0, "cm")) 


qNSCI_plots <- ggarrange(gg2prcl, gg2path, nrow= 1, ncol =2, align = "hv")
print(qNSCI_plots)
ggsave("qNSCI.tiff", units="in", width=13.125, height=5.25, dpi=300, compression="lzw")
###########################################################################################################################
## qNSCII protein class
qNSCIIprcl <- read_csv("qNSCIIprcl.csv", 
                       col_types = cols(Cluster = col_number(), 
                                        FDR = col_skip(), Fold_Enrichment = col_skip(), 
                                        notes = col_skip(), notes_1 = col_skip(), 
                                        pvalue = col_skip()))

gg4prcl <- ggplot(qNSCIIprcl) + geom_rect(data = qNSCIIprcl,aes(fill = Cluster_2),xmin = -Inf,xmax = Inf, ymin = -Inf,ymax = Inf,alpha = 0.3) + 
  scale_fill_manual(values = alpha(c("#ff3030", "grey95", "#365ef8"), .3)) + 
  geom_point(aes(x = Cluster_2, y =reorder(Protein_Class, Fold_Score), size = Fold_Score, color=sig_score)) +
  labs(title="", y="") + scale_color_gradient2(low="blue", mid="grey60", high="black") + facet_grid(~ Cluster_2, scales = "free_x") + theme(strip.background = element_blank(), strip.text.x = element_blank())

gg4prcl <- gg4prcl + theme(legend.position = "left", plot.title=element_text(size=10, 
                                                                             face="bold", 
                                                                             family="Arial",
                                                                             color="black",
                                                                             hjust=0.5,
                                                                             lineheight=1.2),  # title
                           plot.subtitle=element_text(size=15, 
                                                      family="Arial",
                                                      face="bold",
                                                      hjust=0.5),  # subtitle
                           plot.caption=element_text(size=8),  # caption
                           
                           axis.title.x=element_text(vjust=10,  
                                                     size=0),  # X axis title
                           axis.title.y=element_text(size=15),  # Y axis title
                           axis.text.x=element_text(size=0, 
                                                    angle = 90,
                                                    vjust=.5,
                                                    face="bold"),  # X axis text
                           axis.text.y=element_text(size=14, face="bold", colour="black"),
                           
                           panel.grid.major = element_line(colour = "grey", size=.5),
                           panel.grid.minor = element_line(colour = "grey", 
                                                           size=.25, 
                                                           linetype = "dashed"),
                           panel.border = element_rect(size = 1.25, fill = NA),
                           axis.line.x = element_line(colour = "black", 
                                                      size=1.25, 
                                                      lineend = "butt"),
                           axis.line.y = element_line(colour = "black", 
                                                      size=1.25),
                           axis.ticks = element_line(size = 1, colour = "black"),
                           axis.ticks.length = unit(0, "cm")) 


## qNSCII Pathways
qNSCIIpath <- read_csv("qNSCIIpath.csv", 
                       col_types = cols(Cluster = col_number(), 
                                        FDR = col_skip(), Fold_Enrichment = col_skip(), 
                                        notes = col_skip(), notes_1 = col_skip(), 
                                        pvalue = col_skip()))


gg4path <- ggplot(qNSCIIpath) + geom_rect(data = qNSCIIpath,aes(fill = Cluster_2),xmin = -Inf,xmax = Inf, ymin = -Inf,ymax = Inf,alpha = 0.3) + 
  scale_fill_manual(values = alpha(c("#ff3030", "grey95", "#365ef8"), .3)) + 
  geom_point(aes(x = Cluster_2, y =reorder(Pathways, Fold_Score), size = Fold_Score, color=sig_score)) +
  labs(title="", y="") + scale_color_gradient2(low="blue", mid="grey60", high="black") + facet_grid(~ Cluster_2, scales = "free_x") + theme(strip.background = element_blank(), strip.text.x = element_blank())

gg4path <- gg4path + theme(legend.position = "left", plot.title=element_text(size=10, 
                                                                             face="bold", 
                                                                             family="Arial",
                                                                             color="black",
                                                                             hjust=0.5,
                                                                             lineheight=1.2),  # title
                           plot.subtitle=element_text(size=15, 
                                                      family="Arial",
                                                      face="bold",
                                                      hjust=0.5),  # subtitle
                           plot.caption=element_text(size=8),  # caption
                           
                           axis.title.x=element_text(vjust=10,  
                                                     size=0),  # X axis title
                           axis.title.y=element_text(size=15),  # Y axis title
                           axis.text.x=element_text(size=0, 
                                                    angle = 90,
                                                    vjust=.5,
                                                    face="bold"),  # X axis text
                           axis.text.y=element_text(size=14, face="bold", colour="black"),
                           
                           panel.grid.major = element_line(colour = "grey", size=.5),
                           panel.grid.minor = element_line(colour = "grey", 
                                                           size=.25, 
                                                           linetype = "dashed"),
                           panel.border = element_rect(size = 1.25, fill = NA),
                           axis.line.x = element_line(colour = "black", 
                                                      size=1.25, 
                                                      lineend = "butt"),
                           axis.line.y = element_line(colour = "black", 
                                                      size=1.25),
                           axis.ticks = element_line(size = 1, colour = "black"),
                           axis.ticks.length = unit(0, "cm")) 

qNSCII_plots <- ggarrange(gg4prcl, gg4path, nrow= 1, ncol =2, align = "hv")
print(qNSCII_plots)
ggsave("qNSCII.tiff", units="in", width=13.125, height=5.25, dpi=300, compression="lzw")
###########################################################################################################################
## pNSC protein class
pNSCprcl <- read_csv("pNSCprcl.csv", 
                     col_types = cols(Cluster = col_number(), 
                                      FDR = col_skip(), Fold_Enrichment = col_skip(), 
                                      notes = col_skip(), notes_1 = col_skip(), 
                                      pvalue = col_skip()))

gg6prcl <- ggplot(pNSCprcl) + geom_rect(data = pNSCprcl, aes(fill = Cluster_2),xmin = -Inf,xmax = Inf, ymin = -Inf,ymax = Inf,alpha = 0.3) + 
  scale_fill_manual(values = alpha(c("#ff3030", "grey95", "#365ef8"), .3)) + 
  geom_point(aes(x = Cluster_2, y =reorder(Protein_Class, Fold_Score), size = Fold_Score, color=sig_score)) +
  labs(title="", y="") + scale_color_gradient2(low="blue", mid="grey60", high="black") + facet_grid(~ Cluster_2, scales = "free_x") + theme(strip.background = element_blank(), strip.text.x = element_blank())

gg6prcl <- gg6prcl + theme(legend.position = "left", plot.title=element_text(size=10, 
                                                                             face="bold", 
                                                                             family="Arial",
                                                                             color="black",
                                                                             hjust=0.5,
                                                                             lineheight=1.2),  # title
                           plot.subtitle=element_text(size=15, 
                                                      family="Arial",
                                                      face="bold",
                                                      hjust=0.5),  # subtitle
                           plot.caption=element_text(size=8),  # caption
                           
                           axis.title.x=element_text(vjust=10,  
                                                     size=0),  # X axis title
                           axis.title.y=element_text(size=15),  # Y axis title
                           axis.text.x=element_text(size=0, 
                                                    angle = 90,
                                                    vjust=.5,
                                                    face="bold"),  # X axis text
                           axis.text.y=element_text(size=14, face="bold", colour="black"),
                           
                           panel.grid.major = element_line(colour = "grey", size=.5),
                           panel.grid.minor = element_line(colour = "grey", 
                                                           size=.25, 
                                                           linetype = "dashed"),
                           panel.border = element_rect(size = 1.25, fill = NA),
                           axis.line.x = element_line(colour = "black", 
                                                      size=1.25, 
                                                      lineend = "butt"),
                           axis.line.y = element_line(colour = "black", 
                                                      size=1.25),
                           axis.ticks = element_line(size = 1, colour = "black"),
                           axis.ticks.length = unit(0, "cm")) 


## pNSC Pathways
pNSCpath <- read_csv("pNSCpath.csv", 
                     col_types = cols(Cluster = col_number(), 
                                      FDR = col_skip(), Fold_Enrichment = col_skip(), 
                                      notes = col_skip(), notes_1 = col_skip(), 
                                      pvalue = col_skip()))


gg6path <- ggplot(pNSCpath) + geom_rect(data = pNSCpath, aes(fill = Cluster_2),xmin = -Inf,xmax = Inf, ymin = -Inf,ymax = Inf,alpha = 0.3) + 
  scale_fill_manual(values = alpha(c("#ff3030", "grey95", "#365ef8"), .3)) + 
  geom_point(aes(x = Cluster_2, y =reorder(Pathways, Fold_Score), size = Fold_Score, color=sig_score)) +
  labs(title="", y="") + scale_color_gradient2(low="blue", mid="grey60", high="black") + facet_grid(~ Cluster_2, scales = "free_x") + theme(strip.background = element_blank(), strip.text.x = element_blank())

gg6path <- gg6path + theme(legend.position = "left", plot.title=element_text(size=10, 
                                                                             face="bold", 
                                                                             family="Arial",
                                                                             color="black",
                                                                             hjust=0.5,
                                                                             lineheight=1.2),  # title
                           plot.subtitle=element_text(size=15, 
                                                      family="Arial",
                                                      face="bold",
                                                      hjust=0.5),  # subtitle
                           plot.caption=element_text(size=8),  # caption
                           
                           axis.title.x=element_text(vjust=10,  
                                                     size=0),  # X axis title
                           axis.title.y=element_text(size=15),  # Y axis title
                           axis.text.x=element_text(size=0, 
                                                    angle = 90,
                                                    vjust=.5,
                                                    face="bold"),  # X axis text
                           axis.text.y=element_text(size=14, face="bold", colour="black"),
                           
                           panel.grid.major = element_line(colour = "grey", size=.5),
                           panel.grid.minor = element_line(colour = "grey", 
                                                           size=.25, 
                                                           linetype = "dashed"),
                           panel.border = element_rect(size = 1.25, fill = NA),
                           axis.line.x = element_line(colour = "black", 
                                                      size=1.25, 
                                                      lineend = "butt"),
                           axis.line.y = element_line(colour = "black", 
                                                      size=1.25),
                           axis.ticks = element_line(size = 1, colour = "black"),
                           axis.ticks.length = unit(0, "cm")) 


pNSC_plots <- ggarrange(gg6prcl, gg6path, nrow= 1, ncol =2, align = "hv")
print(pNSC_plots)
ggsave("pNSC.tiff", units="in", width=13.125, height=5.25, dpi=300, compression="lzw")
###########################################################################################################################
## aNSC  protein class
aNSCprcl <- read_csv("aNSCprcl.csv", 
                     col_types = cols(Cluster = col_number(), 
                                      FDR = col_skip(), Fold_Enrichment = col_skip(), 
                                      notes = col_skip(), notes_1 = col_skip(), 
                                      pvalue = col_skip()))

gg8prcl <- ggplot(aNSCprcl) + geom_rect(data = aNSCprcl, aes(fill = Cluster_2),xmin = -Inf,xmax = Inf, ymin = -Inf,ymax = Inf,alpha = 0.3) + 
  scale_fill_manual(values = alpha(c("#ff3030", "grey95", "#365ef8"), .3)) + 
  geom_point(aes(x = Cluster_2, y =reorder(Protein_Class, Fold_Score), size = Fold_Score, color=sig_score)) +
  labs(title="", y="") + scale_color_gradient2(low="blue", mid="grey60", high="black") + facet_grid(~ Cluster_2, scales = "free_x") + theme(strip.background = element_blank(), strip.text.x = element_blank())

gg8prcl <- gg8prcl + theme(legend.position = "left", plot.title=element_text(size=10, 
                                                                             face="bold", 
                                                                             family="Arial",
                                                                             color="black",
                                                                             hjust=0.5,
                                                                             lineheight=1.2),  # title
                           plot.subtitle=element_text(size=15, 
                                                      family="Arial",
                                                      face="bold",
                                                      hjust=0.5),  # subtitle
                           plot.caption=element_text(size=8),  # caption
                           
                           axis.title.x=element_text(vjust=10,  
                                                     size=0),  # X axis title
                           axis.title.y=element_text(size=15),  # Y axis title
                           axis.text.x=element_text(size=0, 
                                                    angle = 90,
                                                    vjust=.5,
                                                    face="bold"),  # X axis text
                           axis.text.y=element_text(size=14, face="bold", colour="black"),
                           
                           panel.grid.major = element_line(colour = "grey", size=.5),
                           panel.grid.minor = element_line(colour = "grey", 
                                                           size=.25, 
                                                           linetype = "dashed"),
                           panel.border = element_rect(size = 1.25, fill = NA),
                           axis.line.x = element_line(colour = "black", 
                                                      size=1.25, 
                                                      lineend = "butt"),
                           axis.line.y = element_line(colour = "black", 
                                                      size=1.25),
                           axis.ticks = element_line(size = 1, colour = "black"),
                           axis.ticks.length = unit(0, "cm")) 


## aNSC Pathways
aNSCpath <- read_csv("aNSCpath.csv", 
                     col_types = cols(Cluster = col_number(), 
                                      FDR = col_skip(), Fold_Enrichment = col_skip(), 
                                      notes = col_skip(), notes_1 = col_skip(), 
                                      pvalue = col_skip()))


gg8path <- ggplot(aNSCpath) + geom_rect(data = aNSCpath, aes(fill = Cluster_2),xmin = -Inf,xmax = Inf, ymin = -Inf,ymax = Inf,alpha = 0.3) + 
  scale_fill_manual(values = alpha(c("#ff3030", "grey95", "#365ef8"), .3)) + 
  geom_point(aes(x = Cluster_2, y =reorder(Pathways, Fold_Score), size = Fold_Score, color=sig_score)) +
  labs(title="", y="") + scale_color_gradient2(low="blue", mid="grey60", high="black") + facet_grid(~ Cluster_2, scales = "free_x") + theme(strip.background = element_blank(), strip.text.x = element_blank())

gg8path <- gg8path + theme(legend.position = "left", plot.title=element_text(size=10, 
                                                                             face="bold", 
                                                                             family="Arial",
                                                                             color="black",
                                                                             hjust=0.5,
                                                                             lineheight=1.2),  # title
                           plot.subtitle=element_text(size=15, 
                                                      family="Arial",
                                                      face="bold",
                                                      hjust=0.5),  # subtitle
                           plot.caption=element_text(size=8),  # caption
                           
                           axis.title.x=element_text(vjust=10,  
                                                     size=0),  # X axis title
                           axis.title.y=element_text(size=15),  # Y axis title
                           axis.text.x=element_text(size=0, 
                                                    angle = 90,
                                                    vjust=.5,
                                                    face="bold"),  # X axis text
                           axis.text.y=element_text(size=14, face="bold", colour="black"),
                           
                           panel.grid.major = element_line(colour = "grey", size=.5),
                           panel.grid.minor = element_line(colour = "grey", 
                                                           size=.25, 
                                                           linetype = "dashed"),
                           panel.border = element_rect(size = 1.25, fill = NA),
                           axis.line.x = element_line(colour = "black", 
                                                      size=1.25, 
                                                      lineend = "butt"),
                           axis.line.y = element_line(colour = "black", 
                                                      size=1.25),
                           axis.ticks = element_line(size = 1, colour = "black"),
                           axis.ticks.length = unit(0, "cm")) 


aNSC_plots <- ggarrange(gg8prcl, gg8path, nrow= 1, ncol =2, align = "hv")
print(aNSC_plots)
ggsave("aNSC.tiff", units="in", width=13.125, height=5.25, dpi=300, compression="lzw")
############################################################################################################################
## TAP  protein class
TAPprcl <- read_csv("TAPprcl.csv", 
                    col_types = cols(Cluster = col_number(), 
                                     FDR = col_skip(), Fold_Enrichment = col_skip(), 
                                     notes = col_skip(), notes_1 = col_skip(), 
                                     pvalue = col_skip()))

gg10prcl <- ggplot(TAPprcl) + geom_rect(data = TAPprcl, aes(fill = Cluster_2),xmin = -Inf,xmax = Inf, ymin = -Inf,ymax = Inf,alpha = 0.3) + 
  scale_fill_manual(values = alpha(c("#ff3030", "grey95", "#365ef8"), .3)) + 
  geom_point(aes(x = Cluster_2, y =reorder(Protein_Class, Fold_Score), size = Fold_Score, color=sig_score)) +
  labs(title="", y="") + scale_color_gradient2(low="blue", mid="grey60", high="black") + facet_grid(~ Cluster_2, scales = "free_x") + theme(strip.background = element_blank(), strip.text.x = element_blank())

gg10prcl <- gg10prcl + theme(legend.position = "left", plot.title=element_text(size=10, 
                                                                               face="bold", 
                                                                               family="Arial",
                                                                               color="black",
                                                                               hjust=0.5,
                                                                               lineheight=1.2),  # title
                             plot.subtitle=element_text(size=15, 
                                                        family="Arial",
                                                        face="bold",
                                                        hjust=0.5),  # subtitle
                             plot.caption=element_text(size=8),  # caption
                             
                             axis.title.x=element_text(vjust=10,  
                                                       size=0),  # X axis title
                             axis.title.y=element_text(size=15),  # Y axis title
                             axis.text.x=element_text(size=0, 
                                                      angle = 90,
                                                      vjust=.5,
                                                      face="bold"),  # X axis text
                             axis.text.y=element_text(size=14, face="bold", colour="black"),
                             
                             panel.grid.major = element_line(colour = "grey", size=.5),
                             panel.grid.minor = element_line(colour = "grey", 
                                                             size=.25, 
                                                             linetype = "dashed"),
                             panel.border = element_rect(size = 1.25, fill = NA),
                             axis.line.x = element_line(colour = "black", 
                                                        size=1.25, 
                                                        lineend = "butt"),
                             axis.line.y = element_line(colour = "black", 
                                                        size=1.25),
                             axis.ticks = element_line(size = 1, colour = "black"),
                             axis.ticks.length = unit(0, "cm")) 


## TAP Pathways
TAPpath <- read_csv("TAPpath.csv", 
                    col_types = cols(Cluster = col_number(), 
                                     FDR = col_skip(), Fold_Enrichment = col_skip(), 
                                     notes = col_skip(), notes_1 = col_skip(), 
                                     pvalue = col_skip()))


gg10path <- ggplot(TAPpath) + geom_rect(data = TAPpath, aes(fill = Cluster_2),xmin = -Inf,xmax = Inf, ymin = -Inf,ymax = Inf,alpha = 0.3) + 
  scale_fill_manual(values = alpha(c("#ff3030", "grey95", "#365ef8"), .3)) + 
  geom_point(aes(x = Cluster_2, y =reorder(Pathways, Fold_Score), size = Fold_Score, color=sig_score)) +
  labs(title="", y="") + scale_color_gradient2(low="blue", mid="grey60", high="black") + facet_grid(~ Cluster_2, scales = "free_x") + theme(strip.background = element_blank(), strip.text.x = element_blank())

gg10path <- gg10path + theme(legend.position = "left", plot.title=element_text(size=10, 
                                                                               face="bold", 
                                                                               family="Arial",
                                                                               color="black",
                                                                               hjust=0.5,
                                                                               lineheight=1.2),  # title
                             plot.subtitle=element_text(size=15, 
                                                        family="Arial",
                                                        face="bold",
                                                        hjust=0.5),  # subtitle
                             plot.caption=element_text(size=8),  # caption
                             
                             axis.title.x=element_text(vjust=10,  
                                                       size=0),  # X axis title
                             axis.title.y=element_text(size=15),  # Y axis title
                             axis.text.x=element_text(size=0, 
                                                      angle = 90,
                                                      vjust=.5,
                                                      face="bold"),  # X axis text
                             axis.text.y=element_text(size=14, face="bold", colour="black"),
                             
                             panel.grid.major = element_line(colour = "grey", size=.5),
                             panel.grid.minor = element_line(colour = "grey", 
                                                             size=.25, 
                                                             linetype = "dashed"),
                             panel.border = element_rect(size = 1.25, fill = NA),
                             axis.line.x = element_line(colour = "black", 
                                                        size=1.25, 
                                                        lineend = "butt"),
                             axis.line.y = element_line(colour = "black", 
                                                        size=1.25),
                             axis.ticks = element_line(size = 1, colour = "black"),
                             axis.ticks.length = unit(0, "cm")) 


TAP_plots <- ggarrange(gg10prcl, gg10path, nrow= 1, ncol =2, align = "hv")
print(TAP_plots)
ggsave("TAP.tiff", units="in", width=13.125, height=5.25, dpi=300, compression="lzw")
######################################################################################################################

All6 <- ggarrange(gg2prcl, gg2path, gg4prcl, gg4path, gg6prcl, gg6path, gg8prcl, gg8path, gg10prcl, gg10path, nrow= 5, ncol= 2, align = "hv")
print(All6)
ggsave("All5final.tiff", units="in", width=14.125, height=26.25, dpi=300)



######################################################################################################################
All6 <- ggarrange(gg2prcl, gg2path, gg4prcl, gg4path, gg6prcl, gg6path, gg8prcl, gg8path, gg10prcl, gg10path, nrow= 5, ncol= 2, align = "hv")
print(All6)
ggsave("All5final.tiff", units="in", width=14.125, height=26.25, dpi=600, compression="lzw")