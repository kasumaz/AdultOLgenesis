library(ggplot2)
library(ggpubr)
library(dplyr)
library(readxl)
library(RColorBrewer)
library(readr)
library(directlabels)

display.brewer.all(colorblindFriendly = TRUE)


rm(p)
#to load in the data file with the correct column features
library(readr)
Main <- read_delim("Main.csv", ";", escape_double = FALSE, 
                   col_types = cols(Cluster = col_number(), 
                                    Fold_Enrichment = col_skip(), Notes = col_skip(), 
                                    Notes_1 = col_skip(), Rank = col_skip(), 
                                    pvalue = col_skip()), trim_ws = TRUE)
View(Main)

#  facet_wrap(~Cluster_Number, scales = "free", ncol=4) +
#Wparameters used for constructing plot
p2 <- ggplot(Main, aes(Cluster, Fold_Enrichment_1, group=Pathways, 
                                 color=Pathways), Main$Cluster <- factor(Main$Cluster, levels=c("qNSCI","qNSCII","pNSC", "aNSC", "TAP"))) +
  geom_line(aes(size = Sigscore)) +
  geom_point(aes(size = Sigscore)) + facet_wrap(~Pathways, scales = "free", ncol=6) 
print(p2)
  guides(color = "legend", linetype ="none") # doesnt work

#theme
p2 + theme(legend.position = "right", legend.box = "vertical", plot.title=element_text(size=6, 
                                                                                       face="bold", 
                                                                                       family="Arial",
                                                                                       color="black",
                                                                                       hjust=0.5,                                                                        lineheight=1.2),  # title
           legend.text = element_text(colour="black", size = 8, face = "bold"),
           legend.title = element_text(colour="black", size=8, face="bold"),
           plot.subtitle=element_text(size=15, 
                                      family="Arial",
                                      face="bold",
                                      hjust=0.5),  # subtitle
           plot.caption=element_text(size=6),  # caption
           
           axis.title.x=element_text(vjust=10,  
                                     size=1),  # X axis title
           axis.title.y=element_text(size=15),  # Y axis title
           axis.text.x=element_text(size=10, 
                                    angle = 90,
                                    vjust=.5),  # X axis text
           axis.text.y=element_text(size=10, hjust = 0.5, face = "bold"),
           panel.background = element_rect(fill = 'white'),
           panel.grid.major = element_line(colour = "white", size=.5),
           panel.grid.minor = element_line(colour = "white", 
                                           size=.25, 
                                           linetype = "dashed"),
           panel.border = element_blank(),
           axis.line.x = element_line(colour = "black", 
                                      size=1.5, 
                                      lineend = "butt"),
           axis.line.y = element_line(colour = "black", 
                                      size=1.5),
           axis.ticks = element_line(size = 1, colour = "black"),
           axis.ticks.length = unit(.2, "cm")) 
p2 + theme(legend.position="bottom")
print(p2)

ggsave("PantherTIMEcourse.tiff", units="in", width=15, height=5, dpi=300)

##

#Having the axis in, was tricky for the different cell clusters in order. It worked intially but not later. Plot was adapted/touched up futher in photoshop for homogenising with other figures. 
#The order of plots was also changed around in photoshop and all made black and white as they only represent pathways in the OL lineage. 
#The significance scale was adjusted in photoshop too. 
#The plots for TAPs that have a bigger dot, the line half way from aNSCs to TAPs was expanded because its not easy to see if there was an effect on TAPs compared to the earlier lineage cells. 