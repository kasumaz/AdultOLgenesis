write.csv(dr[["cmd"]][["D2"]], "coordinates.csv")

write.csv(pr[["pr"]][["t13"]][["s"]], "pr_t13.csv")

